const API_URL = 'http://localhost:3000/api/comentarios';

export const obtenerComentarios = async (tareaId) => {
    const response = await fetch(`${API_URL}/${tareaId}`);
    return await response.json();
};

export const agregarComentario = async (texto, tareaId) => {
    const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ texto, tareaId }),
    });
    return await response.json();
};

export const eliminarComentario = async (id) => {
    await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
};
