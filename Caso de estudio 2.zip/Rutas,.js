const express = require('express');
const router = express.Router();
const Comentario = require('../models/Comentario');

// comentarios por tarea
router.get('/:tareaId', async (req, res) => {
    try {
        const comentarios = await Comentario.find({ tareaId: req.params.tareaId });
        res.json(comentarios);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener comentarios' });
    }
});

// Agregar comentario
router.post('/', async (req, res) => {
    const { texto, tareaId } = req.body;
    try {
        const comentario = new Comentario({ texto, tareaId });
        await comentario.save();
        res.status(201).json(comentario);
    } catch (error) {
        res.status(500).json({ error: 'Error al agregar comentario' });
    }
});

// Eliminar comentario
router.delete('/:id', async (req, res) => {
    try {
        await Comentario.findByIdAndDelete(req.params.id);
        res.json({ message: 'Comentario eliminado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar comentario' });
    }
});

module.exports = router;
