import React, { useState, useEffect } from 'react';
import { obtenerComentarios, agregarComentario, eliminarComentario } from '../services/comentarios';

const Comentarios = ({ tareaId }) => {
    const [comentarios, setComentarios] = useState([]);
    const [nuevoComentario, setNuevoComentario] = useState('');

    useEffect(() => {
        const cargarComentarios = async () => {
            const data = await obtenerComentarios(tareaId);
            setComentarios(data);
        };
        cargarComentarios();
    }, [tareaId]);

    const manejarAgregarComentario = async () => {
        const comentario = await agregarComentario(nuevoComentario, tareaId);
        setComentarios([...comentarios, comentario]);
        setNuevoComentario('');
    };

    const manejarEliminarComentario = async (id) => {
        await eliminarComentario(id);
        setComentarios(comentarios.filter((c) => c._id !== id));
    };

    return (
        <div>
            <h3>Comentarios</h3>
            <ul>
                {comentarios.map((comentario) => (
                    <li key={comentario._id}>
                        {comentario.texto}
                        <button onClick={() => manejarEliminarComentario(comentario._id)}>Eliminar</button>
                    </li>
                ))}
            </ul>
            <input
                type="text"
                value={nuevoComentario}
                onChange={(e) => setNuevoComentario(e.target.value)}
                placeholder="Agregar un comentario"
            />
            <button onClick={manejarAgregarComentario}>Agregar</button>
        </div>
    );
};

export default Comentarios;
