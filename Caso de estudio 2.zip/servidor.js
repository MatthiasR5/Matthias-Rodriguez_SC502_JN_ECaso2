const express = require('express');
const mongoose = require('mongoose');
const comentariosRouter = require('./routes/comentarios');
const app = express();

app.use(express.json());

// Conectar a la base de datos
mongoose.connect('mongodb://localhost:27017/tareas', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Rutas
app.use('/api/comentarios', comentariosRouter);

app.listen(3000, () => {
    console.log('Servidor corriendo en el puerto 3000');
});
