// models/Comentario.js
const mongoose = require('mongoose');

const comentarioSchema = new mongoose.Schema({
    texto: {
        type: String,
        required: true,
    },
    tareaId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Tarea',
        required: true,
    },
    fechaCreacion: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Comentario', comentarioSchema);
